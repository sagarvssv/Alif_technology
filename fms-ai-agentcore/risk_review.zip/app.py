import json
import os
import re
import uuid
from datetime import datetime, timezone

import boto3

from checklist_templates import get_template_checklist

RISK_REVIEWS_TABLE = os.environ.get("RISK_REVIEWS_TABLE")
ATTACHMENTS_BUCKET = os.environ.get("ATTACHMENTS_BUCKET")
AWS_REGION = os.environ.get("AWS_REGION", "eu-central-1")

dynamodb = boto3.resource("dynamodb", region_name=AWS_REGION)
s3 = boto3.client("s3", region_name=AWS_REGION)
table = dynamodb.Table(RISK_REVIEWS_TABLE) if RISK_REVIEWS_TABLE else None

CORS_HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token",
    "Access-Control-Allow-Methods": "GET,PUT,POST,OPTIONS",
}

# Current, correct status vocabulary used everywhere in the frontend.
ALLOWED_STATUSES = ["open", "in_process", "review", "closed_resolved", "other"]

# Any risk record created before this vocabulary was introduced may still
# have one of these old values stored in DynamoDB. Map them forward
# automatically instead of rejecting the request.
LEGACY_STATUS_MAP = {
    "in_review": "review",
    "resolved": "closed_resolved",
    "closed": "closed_resolved",
}

# ── Risk level calculation (identical to the portal's frontend formula) ──
RISK_LEVEL_ORDER = ["Low", "Low-Medium", "Medium", "Medium-High", "High"]
RISK_LEVEL_PCT = {
    "high": 90,
    "high (presumed)": 90,
    "medium-high": 75,
    "medium": 55,
    "low-medium": 35,
    "low": 20,
    "to be assessed": 50,
}
IMPROVED_MAX_PCT = 35  # Low-Medium (35%) or lower = "Improved / Low Risk"

# Which stored list each attachment's "checklist" value points at.
CHECKLIST_LISTS = {
    "ai": "checklistItems",
    "mandatory": "mandatoryChecklistItems",
}


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def response(status_code, body):
    return {
        "statusCode": status_code,
        "headers": {**CORS_HEADERS, "Content-Type": "application/json"},
        "body": json.dumps(body, ensure_ascii=False),
    }


def normalize_status(value):
    return LEGACY_STATUS_MAP.get(value, value)


def empty_review(risk_key):
    return {
        "riskKey": risk_key,
        "status": "open",
        "customStatusText": "",
        "comments": [],
        "attachments": [],
        "checklistItems": [],
        "checklistBaseLevel": None,
        "mandatoryChecklistItems": [],
        "statusHistory": [
            {"status": "open", "changedBy": "system", "changedAt": now_iso()}
        ],
        "createdAt": now_iso(),
        "lastUpdated": now_iso(),
    }


def get_review(risk_key):
    result = table.get_item(Key={"risk_key": risk_key})
    item = result.get("Item")
    if not item:
        return empty_review(risk_key)
    return {
        "riskKey": item.get("risk_key"),
        "status": normalize_status(item.get("status", "open")),
        "customStatusText": item.get("custom_status_text", ""),
        "comments": item.get("comments", []),
        "attachments": item.get("attachments", []),
        "checklistItems": item.get("checklist_items", []),
        "checklistBaseLevel": item.get("checklist_base_level"),
        "mandatoryChecklistItems": item.get("mandatory_checklist_items", []),
        "statusHistory": item.get("status_history", []),
        "createdAt": item.get("created_at"),
        "lastUpdated": item.get("last_updated"),
    }


RISK_FLOOR_PCT = 20


def split_level(label):
    """'Medium-High (67%)' -> 'Medium-High'. Plain labels pass through."""
    return re.sub(r"\s*\(\d{1,3}\s*%\)\s*$", "", str(label or "")).strip()


def level_pct(label):
    return RISK_LEVEL_PCT.get(split_level(label).lower())


def classify(pct):
    return "Improved / Low Risk" if pct is not None and pct <= IMPROVED_MAX_PCT else "Needs Attention"


def pct_for(base_pct, done, total):
    """Same as computeRiskFromProgress in Chatbot.jsx: an equal share off
    the original % for every item done, reaching 20% when all are done."""
    if total == 0 or done == 0:
        return base_pct
    if done >= total:
        return min(base_pct, RISK_FLOOR_PCT)
    # JS Math.round rounds .5 up; Python round() would round half to even.
    return int(base_pct - (base_pct - RISK_FLOOR_PCT) * (done / total) + 0.5)


def label_for(pct):
    """Lowest level whose % is still >= the current %."""
    for name in RISK_LEVEL_ORDER:
        if RISK_LEVEL_PCT[name.lower()] >= pct:
            return name
    return "High"


def compute_risk_level(review):
    ai_items = review.get("checklistItems") or []
    mandatory_items = review.get("mandatoryChecklistItems") or []
    is_done = lambda i: bool(i.get("satisfied") or i.get("manuallyChecked"))
    ai_done = sum(1 for i in ai_items if is_done(i))
    mandatory_done = sum(1 for i in mandatory_items if is_done(i))
    total = len(ai_items) + len(mandatory_items)
    done = ai_done + mandatory_done

    counts = {
        "doneCount": done,
        "total": total,
        "aiChecklist": {"done": ai_done, "total": len(ai_items)},
        "mandatoryChecklist": {"done": mandatory_done, "total": len(mandatory_items)},
    }
    base = split_level(review.get("checklistBaseLevel"))
    if not base:
        return {
            "available": False,
            "reason": "Original risk level not recorded yet. It is saved with the first setChecklist "
                      "(baseRiskLevel), or send PUT {\"baseRiskLevel\": \"High\"} once.",
            **counts,
        }

    base_pct = level_pct(base) if level_pct(base) is not None else 90
    current_pct = pct_for(base_pct, done, total)
    current_level = base if (total == 0 or done == 0) else label_for(current_pct)
    improved_at = next((d for d in range(0, total + 1) if pct_for(base_pct, d, total) <= IMPROVED_MAX_PCT), None)

    return {
        "available": True,
        "originalLevel": base,
        "originalPct": base_pct,
        "currentLevel": current_level,
        "currentPct": current_pct,
        **counts,
        "pctPerItem": round((base_pct - RISK_FLOOR_PCT) / total, 1) if total and base_pct > RISK_FLOOR_PCT else 0,
        "classification": classify(current_pct),
        "improvedThresholdPct": IMPROVED_MAX_PCT,
        "itemsNeededForNextDrop": 1 if done < total and current_pct > RISK_FLOOR_PCT else None,
        "itemsNeededForImproved": max(0, improved_at - done) if improved_at is not None else None,
    }


def handle_get(risk_key):
    if not table:
        return response(500, {"error": "RISK_REVIEWS_TABLE not configured"})
    review = get_review(risk_key)
    review["riskLevel"] = compute_risk_level(review)
    return response(200, review)


# ── Evidence helpers ───────────────────────────────────────────────────

def normalize_verdict(raw):
    """Cleans the 5-field relevance verdict exactly the way the agent does:
    resolves_risk can only be true when relevant is true."""
    if not isinstance(raw, dict):
        return None
    relevant = bool(raw.get("relevant", False))
    return {
        "relevant": relevant,
        "resolves_risk": bool(raw.get("resolves_risk", False)) if relevant else False,
        "reason": str(raw.get("reason", "") or ""),
        "specifically_addressed": str(raw.get("specifically_addressed", "") or "") if relevant else "",
        "still_outstanding": str(raw.get("still_outstanding", "") or "") if relevant else "",
    }


def verdict_satisfies(verdict):
    return bool(verdict and verdict.get("relevant") and verdict.get("resolves_risk"))


def find_checklist_item(existing, checklist, item_id):
    list_name = CHECKLIST_LISTS.get(checklist)
    if not list_name:
        return None
    for checklist_item in existing.get(list_name, []):
        if checklist_item.get("id") == item_id:
            return checklist_item
    return None


def apply_verdict_to_item(checklist_item, s3_key, verdict):
    """Marks the item satisfied only when the file is relevant AND resolves
    it. Never downgrades: an already satisfied item keeps its original
    satisfying file, and a non-satisfying file changes nothing."""
    if checklist_item.get("satisfied"):
        return
    if verdict_satisfies(verdict):
        checklist_item["satisfied"] = True
        checklist_item["satisfiedBy"] = s3_key
        checklist_item["justification"] = verdict.get("reason", "")


def release_item_after_removal(existing, removed_attachment):
    """When the file that satisfied an item is removed, the item falls back
    to the next remaining file that also satisfies it, or else becomes
    unsatisfied. A manual confirmation (manuallyChecked) and its
    justification are left untouched."""
    s3_key = removed_attachment.get("s3Key")
    for checklist, list_name in CHECKLIST_LISTS.items():
        for checklist_item in existing.get(list_name, []):
            if checklist_item.get("satisfiedBy") != s3_key:
                continue
            replacement = next(
                (
                    a for a in existing["attachments"]
                    if a.get("itemId") == checklist_item.get("id")
                    and a.get("checklist") == checklist
                    and verdict_satisfies(a.get("verdict"))
                ),
                None,
            )
            if replacement:
                checklist_item["satisfied"] = True
                checklist_item["satisfiedBy"] = replacement["s3Key"]
                checklist_item["justification"] = replacement["verdict"].get("reason", "")
            else:
                checklist_item["satisfied"] = False
                checklist_item["satisfiedBy"] = None
                if not checklist_item.get("manuallyChecked"):
                    checklist_item["justification"] = ""


def patch_checklist_item(items, patch):
    target_id = patch["id"]
    for checklist_item in items:
        if checklist_item.get("id") != target_id:
            continue
        if "satisfied" in patch:
            checklist_item["satisfied"] = bool(patch["satisfied"])
        if "satisfiedBy" in patch:
            checklist_item["satisfiedBy"] = patch["satisfiedBy"]
        if "manuallyChecked" in patch:
            checklist_item["manuallyChecked"] = bool(patch["manuallyChecked"])
        if "justification" in patch:
            checklist_item["justification"] = str(patch["justification"])
        break


def new_checklist(texts):
    return [
        {
            "id": uuid.uuid4().hex,
            "text": str(text).strip(),
            "satisfied": False,
            "satisfiedBy": None,
            "manuallyChecked": False,
            "justification": "",
        }
        for text in texts
        if str(text).strip()
    ]


def handle_put(risk_key, body):
    """
    Body may include any of:
      status, customStatusText, newComment, changedBy  (unchanged)

      newAttachment: {
        fileName,                       required
        s3Key,                          the evidence documentId
        itemId?,                        checklist item this file is evidence for
        checklist?: "ai" | "mandatory", which list itemId belongs to (default "ai")
        verdict?: { relevant, resolves_risk, reason,
                    specifically_addressed, still_outstanding }
      }
        Stores the file with its item link and verdict. When itemId and
        verdict are given, the item is marked satisfied only if
        relevant && resolves_risk, and an already satisfied item is never
        downgraded. Re-sending the same s3Key replaces that attachment
        (safe to retry).

      removeAttachment: { s3Key }
        Removes the file. If it was the file that satisfied an item, the
        item falls back to another satisfying file or becomes unsatisfied.
        One call is a complete undo.

      setChecklist / updateChecklistItem /
      setMandatoryChecklist / updateMandatoryChecklistItem  (unchanged)
        Applied AFTER the attachment fields, so an explicit item update in
        the same PUT always has the final say.
    """
    if not table:
        return response(500, {"error": "RISK_REVIEWS_TABLE not configured"})

    existing = get_review(risk_key)
    changed_by = body.get("changedBy") or "unknown"

    new_status = body.get("status")
    if new_status is not None:
        new_status = normalize_status(new_status)
        if new_status not in ALLOWED_STATUSES:
            return response(400, {"error": f"status must be one of {ALLOWED_STATUSES}"})
        if new_status != existing["status"]:
            existing["statusHistory"].append(
                {"status": new_status, "changedBy": changed_by, "changedAt": now_iso()}
            )
        existing["status"] = new_status

    custom_status_text = body.get("customStatusText")
    if custom_status_text is not None:
        existing["customStatusText"] = custom_status_text

    new_comment = body.get("newComment")
    if new_comment and isinstance(new_comment, dict) and new_comment.get("text"):
        existing["comments"].append(
            {
                "author": new_comment.get("author") or changed_by,
                "text": new_comment["text"],
                "timestamp": now_iso(),
            }
        )

    # Checklists must exist before an attachment can point at their items,
    # so set them first (only takes effect the first time).
    set_checklist = body.get("setChecklist")
    if set_checklist and isinstance(set_checklist, list) and not existing.get("checklistItems"):
        existing["checklistItems"] = new_checklist(set_checklist)
        base_level = body.get("baseRiskLevel")
        if base_level and not existing.get("checklistBaseLevel") and level_pct(base_level) is not None:
            existing["checklistBaseLevel"] = split_level(base_level)

    set_mandatory_checklist = body.get("setMandatoryChecklist")
    if set_mandatory_checklist and isinstance(set_mandatory_checklist, list) and not existing.get("mandatoryChecklistItems"):
        existing["mandatoryChecklistItems"] = new_checklist(set_mandatory_checklist)

    # The ORIGINAL level is recorded once and never overwritten, so every
    # recalculation steps down from the same anchor (no compounding).
    base_risk_level = body.get("baseRiskLevel")
    if base_risk_level and not existing.get("checklistBaseLevel"):
        if level_pct(base_risk_level) is None:
            return response(400, {"error": f"baseRiskLevel must be one of {RISK_LEVEL_ORDER + ['High (Presumed)', 'To Be Assessed']}"})
        existing["checklistBaseLevel"] = split_level(base_risk_level)

    new_attachment = body.get("newAttachment")
    if new_attachment and isinstance(new_attachment, dict) and new_attachment.get("fileName"):
        s3_key = str(new_attachment.get("s3Key") or "").strip()
        if not s3_key:
            return response(400, {"error": "newAttachment.s3Key is required (the evidence documentId)"})
        item_id = new_attachment.get("itemId")
        checklist = new_attachment.get("checklist") or "ai"
        verdict = normalize_verdict(new_attachment.get("verdict"))

        target_item = None
        if item_id:
            if checklist not in CHECKLIST_LISTS:
                return response(400, {"error": 'newAttachment.checklist must be "ai" or "mandatory"'})
            target_item = find_checklist_item(existing, checklist, item_id)
            if target_item is None:
                return response(400, {"error": f"No {checklist} checklist item with id {item_id} on this risk"})

        record = {
            "fileName": new_attachment["fileName"],
            "s3Key": s3_key,
            "uploadedBy": changed_by,
            "uploadedAt": now_iso(),
        }
        if item_id:
            record["itemId"] = item_id
            record["checklist"] = checklist
        if verdict:
            record["verdict"] = verdict
            record["checkedAt"] = now_iso()

        if s3_key:
            existing["attachments"] = [a for a in existing["attachments"] if a.get("s3Key") != s3_key]
        existing["attachments"].append(record)

        if target_item is not None and verdict:
            apply_verdict_to_item(target_item, s3_key, verdict)

    remove_attachment = body.get("removeAttachment")
    if remove_attachment and isinstance(remove_attachment, dict) and remove_attachment.get("s3Key"):
        removed = [a for a in existing["attachments"] if a.get("s3Key") == remove_attachment["s3Key"]]
        existing["attachments"] = [
            a for a in existing["attachments"] if a.get("s3Key") != remove_attachment["s3Key"]
        ]
        release_item_after_removal(existing, {"s3Key": remove_attachment["s3Key"]})
        if not removed:
            existing["removeAttachmentNote"] = "No attachment with that s3Key was found; nothing removed."
    elif remove_attachment and isinstance(remove_attachment, dict) and remove_attachment.get("uploadedAt"):
        # Cleanup path for records saved without an s3Key (they cannot be
        # matched by key). Matches on the exact uploadedAt timestamp.
        existing["attachments"] = [
            a for a in existing["attachments"]
            if not (not a.get("s3Key") and a.get("uploadedAt") == remove_attachment["uploadedAt"])
        ]

    update_checklist_item = body.get("updateChecklistItem")
    if update_checklist_item and isinstance(update_checklist_item, dict) and update_checklist_item.get("id"):
        patch_checklist_item(existing.get("checklistItems", []), update_checklist_item)

    update_mandatory_checklist_item = body.get("updateMandatoryChecklistItem")
    if update_mandatory_checklist_item and isinstance(update_mandatory_checklist_item, dict) and update_mandatory_checklist_item.get("id"):
        patch_checklist_item(existing.get("mandatoryChecklistItems", []), update_mandatory_checklist_item)

    existing["lastUpdated"] = now_iso()
    if not existing.get("createdAt"):
        existing["createdAt"] = existing["lastUpdated"]

    table.put_item(
        Item={
            "risk_key": risk_key,
            "status": existing["status"],
            "custom_status_text": existing.get("customStatusText", ""),
            "comments": existing["comments"],
            "attachments": existing["attachments"],
            "checklist_items": existing.get("checklistItems", []),
            "checklist_base_level": existing.get("checklistBaseLevel"),
            "mandatory_checklist_items": existing.get("mandatoryChecklistItems", []),
            "status_history": existing["statusHistory"],
            "created_at": existing["createdAt"],
            "last_updated": existing["lastUpdated"],
        }
    )

    existing["riskLevel"] = compute_risk_level(existing)
    return response(200, existing)


def handle_get_checklist_template(query_params):
    """GET /checklist-templates?area=<risk_area>"""
    area = (query_params or {}).get("area", "")
    if not area:
        return response(400, {"error": "area query parameter is required"})
    items = get_template_checklist(area)
    return response(200, {"area": area, "items": items or []})


def handle_attachment_url(risk_key, body):
    """
    Presigned PUT for a raw file stored against a risk. NOTE: files sent
    here do NOT go through Textract, so they cannot be relevance-checked.
    Evidence for checklist items should use POST /upload-url instead.
    Accepts both camelCase and snake_case field names.
    """
    if not ATTACHMENTS_BUCKET:
        return response(500, {"error": "ATTACHMENTS_BUCKET not configured"})

    file_name = body.get("fileName") or body.get("file_name") or f"attachment-{uuid.uuid4().hex}"
    content_type = body.get("contentType") or body.get("content_type") or "application/octet-stream"
    safe_name = "".join(c for c in file_name if c.isalnum() or c in "._-") or "attachment"
    s3_key = f"risk-attachments/{risk_key}/{uuid.uuid4().hex}-{safe_name}"

    upload_url = s3.generate_presigned_url(
        "put_object",
        Params={"Bucket": ATTACHMENTS_BUCKET, "Key": s3_key, "ContentType": content_type},
        ExpiresIn=300,
    )

    return response(200, {"uploadUrl": upload_url, "s3Key": s3_key, "fileName": file_name})


def lambda_handler(event, context):
    try:
        method = event.get("httpMethod", "GET")
        path_params = event.get("pathParameters") or {}
        risk_key = path_params.get("riskKey", "")
        resource_path = event.get("resource", "") or event.get("path", "")

        if method == "OPTIONS":
            return response(200, {})

        # No riskKey in this path, so it must be checked before the guard below.
        if method == "GET" and "checklist-templates" in resource_path:
            return handle_get_checklist_template(event.get("queryStringParameters"))

        if not risk_key:
            return response(400, {"error": "riskKey is required in the URL path"})

        raw_body = event.get("body") or "{}"
        try:
            body = json.loads(raw_body) if isinstance(raw_body, str) else (raw_body or {})
        except Exception:
            body = {}

        if method == "GET":
            return handle_get(risk_key)

        if method == "PUT":
            return handle_put(risk_key, body)

        if method == "POST" and "attachment-url" in resource_path:
            return handle_attachment_url(risk_key, body)

        return response(405, {"error": f"Method {method} not supported on this resource"})

    except Exception as exc:
        return response(500, {"error": str(exc)})