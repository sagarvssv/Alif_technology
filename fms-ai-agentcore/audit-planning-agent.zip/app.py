import json
import os
import traceback
from http.server import BaseHTTPRequestHandler, HTTPServer

AGENT_NAME = "audit_planning_agent"
PORT = int(os.environ.get("PORT", "8080"))

GENERATE_TRIGGERS = [
    "generate audit planning",
    "generate audit plan",
    "generate the audit",
    "create audit plan",
    "create audit planning",
    "produce audit plan",
    "start audit planning",
    "run audit planning",
    "audit planning.",
    "audit planning report",
]

IMPROVE_TRIGGERS = [
    "improve",
    "how to reduce",
    "how to fix",
    "how to address",
    "how to mitigate",
    "reduce the risk",
    "fix the risk",
    "address the risk",
    "mitigate the risk",
    "what can i do about",
    "what should i do about",
    "recommendations for",
    "action plan for",
    "steps to improve",
    "steps to fix",
    "steps to reduce",
    "overcome",
    "solve",
    "remediate",
]


def safe_json_dumps(data):
    return json.dumps(data, ensure_ascii=False)


def safe_json_loads(value, default=None):
    if default is None:
        default = {}
    if not value:
        return default
    if isinstance(value, bytes):
        value = value.decode("utf-8", errors="ignore")
    try:
        return json.loads(value)
    except Exception:
        return default


def prepare_imports():
    import sys
    current_dir = os.path.dirname(os.path.abspath(__file__))
    agentcore_dir = os.path.abspath(os.path.join(current_dir, ".."))
    if agentcore_dir not in sys.path:
        sys.path.append(agentcore_dir)


def is_generate_request(message: str) -> bool:
    msg = message.lower().strip()
    for trigger in GENERATE_TRIGGERS:
        if trigger in msg:
            return True
    return False


def is_improve_request(message: str) -> bool:
    msg = message.lower().strip()
    for trigger in IMPROVE_TRIGGERS:
        if trigger in msg:
            return True
    return False


def extract_risk_area(message: str) -> str:
    """Extract which risk area the user is asking about."""
    msg = message.lower()
    risk_areas = [
        "corporate tax", "vat", "inventory", "revenue", "receivables",
        "related party", "going concern", "lease", "fraud", "accrual",
        "disclosure", "materiality", "staffing", "engagement",
    ]
    for area in risk_areas:
        if area in msg:
            return area
    return ""

# ─── Risk Checklist Decomposition (NEW) ──────────────────────────────
# Breaks one risk's Planned Response into a short list of distinct,
# independently-checkable items. This lets the frontend show each item
# with its own checkbox and its own upload button, instead of treating
# the whole risk as one all-or-nothing block.
def decompose_risk_into_checklist(invoke_claude, risk_area, risk_description, planned_response):
    system_prompt = """
You are breaking down a single audit risk's Planned Response into a
short checklist of distinct, individually-verifiable items. Respond
with STRICT JSON only — no other text, no markdown code fences.

Schema (exactly this one field):
{
  "items": ["first checkable item", "second checkable item", ...]
}

Rules:
- Produce between 2 and 6 items. Most risks need 3-5.
- Each item must describe ONE concrete, independently checkable fact or
  condition drawn directly from the Planned Response and Risk
  Description below (e.g. "Confirm the AED 98,400 balance owed by Al
  Fahim Trading" or "Explain the AED 38,000 in deposits in transit").
- Items must be genuinely separable — evidence could satisfy one
  without satisfying the others.
- Do NOT invent facts, customer names, or amounts not present in the
  Risk Description or Planned Response text below. If specific names or
  numbers are present, use them. If not, phrase items generically
  around what the Planned Response asks the auditor to check.
- Keep each item to one short sentence, plain English.
- Never produce vague items like "review the situation" — every item
  must be something a specific document could either satisfy or not.
"""
    user_prompt = f"""
Risk area: {risk_area}
Risk description: {risk_description}
Planned Response: {planned_response}

Return the JSON checklist now. Nothing else.
"""
    result = invoke_claude(
        system_prompt=system_prompt,
        user_prompt=user_prompt,
        max_tokens=400,
        temperature=0,
    )
    cleaned = (result or "").strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.strip("`")
        if cleaned.lower().startswith("json"):
            cleaned = cleaned[4:].strip()
    try:
        parsed = json.loads(cleaned)
        items = parsed.get("items", [])
        items = [str(i).strip() for i in items if str(i).strip()]
        if not items:
            raise ValueError("empty checklist")
        return items[:6]
    except Exception:
        # Fallback: treat the whole planned response as a single item so
        # the feature degrades gracefully instead of breaking the modal.
        return [planned_response.strip()] if planned_response.strip() else [
            "Review and confirm this risk area."
        ]

# ─── Deterministic Evidence Relevance Check (PERMANENT FIX) ─────────────
# Replaces the old approach of asking the AI to regenerate the ENTIRE
# report and hoping the target risk's row changed in a sensible way.
# That approach was non-deterministic: the same document uploaded twice
# could produce different risk levels, and there was no way to guarantee
# "not relevant" evidence left the risk untouched.
#
# Instead: ask the AI ONLY two narrow yes/no questions about ONE risk and
# ONE document. The frontend then computes the new risk level itself
# using a fixed lookup table — never trusting the AI to invent a level —
# so the same (relevant, resolves) answer ALWAYS produces the same
# outcome, every single time.
def assess_evidence_relevance(invoke_claude, risk_area, risk_description, planned_response, evidence_text):
    system_prompt = """
You are assessing whether a specific document is relevant evidence for a
specific audit risk. Respond with STRICT JSON only — no other text, no
markdown code fences, no explanation outside the JSON object.

Schema (exactly these five fields, nothing else):
{
  "relevant": true or false,
  "resolves_risk": true or false,
  "reason": "one short sentence explaining your decision",
  "specifically_addressed": "what part of the risk this document actually confirms, in plain terms — empty string if not relevant",
  "still_outstanding": "what part of the Planned Response remains unconfirmed or unexplained by this document — empty string if fully resolved or not relevant"
}

Rules:
- "relevant" = false if the document has nothing meaningfully to do with
  this specific risk area (e.g. a trade license uploaded for a bank
  reconciliation risk, or a VAT return uploaded for a fixed asset risk).
  If relevant is false, resolves_risk MUST also be false, and both
  specifically_addressed and still_outstanding MUST be empty strings.
- "relevant" = true if the document discusses, confirms, explains, or
  directly addresses this risk's subject matter, even partially.
- "resolves_risk" = true ONLY if the document fully and directly answers
  everything described in the Planned Response below — every number,
  every condition, with no gaps remaining. In this case
  still_outstanding MUST be an empty string.
- "resolves_risk" = false if the document is relevant but leaves any
  part of the Planned Response unaddressed or unconfirmed.
- "specifically_addressed" must name the CONCRETE fact confirmed (e.g.
  "Bank balance of AED 542,000 confirmed by bank statement"), not a
  vague summary. This is required whenever relevant is true.
- "still_outstanding" must name the CONCRETE gap that remains (e.g.
  "The AED 62,000 reconciling difference between books and bank is not
  explained — no listing of outstanding cheques or deposits in
  transit was provided"). This is required whenever relevant is true
  and resolves_risk is false.
- Be decisive. Do not hedge. Pick true or false for each boolean field.
- Never invent facts not present in the evidence document text.
"""
    user_prompt = f"""
Risk area: {risk_area}
Risk description: {risk_description}
Planned Response (exactly what evidence would need to show to resolve this risk):
{planned_response}

Evidence document text (this is the ONLY document being assessed):
{evidence_text}

Return the JSON assessment now. Nothing else.
"""
    result = invoke_claude(
        system_prompt=system_prompt,
        user_prompt=user_prompt,
        max_tokens=300,
        temperature=0,
    )
    cleaned = (result or "").strip()
    # Strip accidental markdown fences if the model adds them anyway.
    if cleaned.startswith("```"):
        cleaned = cleaned.strip("`")
        if cleaned.lower().startswith("json"):
            cleaned = cleaned[4:].strip()
    try:
        parsed = json.loads(cleaned)
        is_relevant = bool(parsed.get("relevant", False))
        return {
            "relevant": is_relevant,
            "resolves_risk": bool(parsed.get("resolves_risk", False)) if is_relevant else False,
            "reason": str(parsed.get("reason", "")).strip() or "No reason provided.",
            "specifically_addressed": str(parsed.get("specifically_addressed", "")).strip() if is_relevant else "",
            "still_outstanding": str(parsed.get("still_outstanding", "")).strip() if is_relevant else "",
        }
    except Exception:
        return {
            "relevant": False,
            "resolves_risk": False,
            "reason": "Could not determine relevance — the assessment could not be parsed. Treating as not relevant to avoid an incorrect risk reduction.",
            "specifically_addressed": "",
            "still_outstanding": "",
        }


def run_agent(payload):
    prepare_imports()

    from shared.bedrock import invoke_claude
    from shared.kb import retrieve_from_kb, format_citations
    from shared.report_context import get_combined_report_context, build_context_summary
    from shared.utils import (
        build_response,
        compact_text,
        get_direct_context_from_payload,
        get_message_from_payload,
        get_report_ids_from_payload,
    )
    # ── Risk checklist decomposition route (checked first, same reason
    # as the relevance-check route below — it only needs risk text, not
    # any document context or general_mode gating). ────────────────────
    risk_checklist_request = payload.get("riskChecklist")
    if risk_checklist_request and isinstance(risk_checklist_request, dict):
        items = decompose_risk_into_checklist(
            invoke_claude=invoke_claude,
            risk_area=risk_checklist_request.get("riskArea", ""),
            risk_description=risk_checklist_request.get("riskDescription", ""),
            planned_response=risk_checklist_request.get("plannedResponse", ""),
        )
        return build_response(
            answer=json.dumps({"items": items}),
            selected_agent=AGENT_NAME,
            citations=[],
            extra={"agentType": "risk_checklist", "agentName": "Audit Planning Agent"},
        )
    # ── Deterministic relevance-check route (checked FIRST, before any
    # other routing, since it doesn't need the general_mode/report_ids
    # gating below — it only needs the single evidence document). ──────
    relevance_check = payload.get("relevanceCheck")
    if relevance_check and isinstance(relevance_check, dict):
        evidence_report_ids = get_report_ids_from_payload(payload)
        direct_context_rc = get_direct_context_from_payload(payload)
        evidence_text = get_combined_report_context(
            report_ids=evidence_report_ids, direct_context=direct_context_rc
        )
        evidence_text = compact_text(evidence_text, max_chars=12000)

        verdict = assess_evidence_relevance(
            invoke_claude=invoke_claude,
            risk_area=relevance_check.get("riskArea", ""),
            risk_description=relevance_check.get("riskDescription", ""),
            planned_response=relevance_check.get("plannedResponse", ""),
            evidence_text=evidence_text,
        )
        return build_response(
            answer=json.dumps(verdict),
            selected_agent=AGENT_NAME,
            citations=[],
            extra={"agentType": "relevance_check", "agentName": "Audit Planning Agent"},
        )

    original_user_message = get_message_from_payload(payload)
    report_ids             = get_report_ids_from_payload(payload)
    direct_context        = get_direct_context_from_payload(payload)

    general_mode = (
        payload.get("generalMode", False)
        or payload.get("general_mode", False)
        or payload.get("selectedAgent") == "general_kb_agent"
        or payload.get("agent") == "general_kb_agent"
    )

    user_message = original_user_message or "Generate audit planning."

    # ── GENERAL Q&A MODE ─────────────────────────────────────────────
    if general_mode or not report_ids:
        kb_context, citations = retrieve_from_kb(user_message, number_of_results=6)
        answer = answer_general_question(
            invoke_claude=invoke_claude,
            user_message=user_message,
            kb_context=kb_context,
        )
        return build_response(
            answer=answer,
            selected_agent=AGENT_NAME,
            citations=citations,
            extra={"agentType": "general", "agentName": "General Q&A Agent"},
        )

    # ── Load document context (one or many uploaded files, combined) ──
    report_context  = get_combined_report_context(report_ids=report_ids, direct_context=direct_context)
    # Multiple documents need more room than a single one before truncating.
    max_context_chars = 18000 * min(len(report_ids), 3)
    context_summary = build_context_summary(compact_text(report_context, max_chars=max_context_chars))

    # ── ROUTE ─────────────────────────────────────────────────────────
    if is_generate_request(user_message):
        # Full audit planning report generation
        kb_query = build_kb_query(user_message, report_context, compact_text)
        kb_context, citations = retrieve_from_kb(kb_query, number_of_results=6)
        citation_details = format_citations(citations)

        answer = generate_complete_audit_planning_output(
            invoke_claude=invoke_claude,
            user_message=user_message,
            report_context=context_summary,
            kb_context=kb_context,
            citation_details=citation_details,
            document_count=len(report_ids),
        )

    elif is_improve_request(user_message):
        # Risk improvement plan for a specific area
        risk_area = extract_risk_area(user_message)
        kb_context, citations = retrieve_from_kb(
            f"how to improve {risk_area} audit risk UAE IFRS ISA", number_of_results=6
        )

        answer = generate_risk_improvement_plan(
            invoke_claude=invoke_claude,
            user_message=user_message,
            risk_area=risk_area,
            report_context=context_summary,
            kb_context=kb_context,
        )

    else:
        # General follow-up question about the document
        kb_context, citations = retrieve_from_kb(user_message, number_of_results=5)

        answer = answer_document_question(
            invoke_claude=invoke_claude,
            user_message=user_message,
            report_context=context_summary,
            kb_context=kb_context,
        )

    return build_response(
        answer=answer,
        selected_agent=AGENT_NAME,
        citations=citations,
        extra={"agentType": "sub_agent", "agentName": "Audit Planning Agent"},
    )


# ── General KB question (no document) ────────────────────────────────
def answer_general_question(invoke_claude, user_message, kb_context):
    system_prompt = """
You are a UAE financial and audit compliance expert assistant.
Answer the user's question clearly and directly using the Knowledge Base context provided.

STRICT RULES:
- Answer ONLY the specific question asked.
- Do NOT generate an audit planning report.
- Do NOT produce sections like Engagement Strategy, Risk Assessment, Audit Programs, Staffing.
- Use plain, professional English.
- Maximum 400 words.
- Use bullet points where helpful.
- If not in the knowledge base say: "This detail is not in the available knowledge base. Please consult a qualified professional."
"""
    user_prompt = f"""
Knowledge Base context:
{kb_context or "No knowledge base results found."}

User question:
{user_message}

Answer the question directly and concisely.
"""
    try:
        result = invoke_claude(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            max_tokens=800,
            temperature=0,
        )
        return (result or "").strip()
    except Exception as exc:
        return f"Unable to retrieve an answer at this time. Error: {str(exc)}"


# ── Follow-up question about uploaded document ────────────────────────
def answer_document_question(invoke_claude, user_message, report_context, kb_context):
    system_prompt = """
You are an expert audit and financial analyst assistant.
The user has an uploaded financial document and has already seen the full audit plan.
They are now asking a specific follow-up question about it.

STRICT RULES:
- Answer ONLY the specific question asked.
- Do NOT regenerate the full audit plan.
- Do NOT produce the full report sections.
- Use the financial data from the document context to give accurate, specific answers.
- Use actual AED numbers from the document where relevant.
- Maximum 500 words. Use bullet points where helpful.
- Be direct, specific, and professional.
"""
    user_prompt = f"""
Document financial data:
{report_context or "No document context available."}

Knowledge Base guidance:
{kb_context or "No knowledge base results found."}

User question:
{user_message}

Answer this specific question using the document data above.
Do NOT generate a full audit plan. Give a focused, helpful answer.
"""
    try:
        result = invoke_claude(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            max_tokens=1000,
            temperature=0,
        )
        return (result or "").strip()
    except Exception as exc:
        return f"Unable to answer this question. Error: {str(exc)}"


# ── Risk improvement plan ──────────────────────────────────────────────
def generate_risk_improvement_plan(
    invoke_claude, user_message, risk_area, report_context, kb_context
):
    system_prompt = """
You are a senior audit expert and risk management specialist.
The user wants a detailed, actionable improvement plan for a specific risk area
identified in their audit planning report.

FORMAT RULES:
- Give a structured, professional improvement plan.
- Use clear headings and numbered steps.
- Include specific actions management should take.
- Include what the auditor will verify after improvements.
- Use actual numbers from the document where available.
- Maximum 600 words.
- Do NOT regenerate the full audit plan.
- Focus ONLY on the specific risk area asked about.
"""
    area_label = risk_area.title() if risk_area else "the identified risk area"
    user_prompt = f"""
Document financial data:
{report_context or "No document context available."}

Knowledge Base guidance:
{kb_context or "No knowledge base results found."}

User request:
{user_message}

The user wants to improve the **{area_label}** risk area.

Generate a detailed improvement plan with this structure:

## 🎯 Risk Area: {area_label}

### Current Risk Status
Briefly describe the current risk level and why it exists based on the document data.

### 📋 Management Action Plan
Numbered list of specific steps management must take to reduce this risk.
Use actual document figures where relevant (AED amounts, percentages, dates).

### ✅ How the Auditor Will Verify Improvement
Numbered list of what the auditor will check to confirm the risk has been reduced.

### 📊 Expected Outcome
Brief statement on what risk level this area should reach after improvements are implemented.

Be specific, practical, and use plain English.
"""
    try:
        result = invoke_claude(
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            max_tokens=1200,
            temperature=0,
        )
        return (result or "").strip()
    except Exception as exc:
        return f"Unable to generate improvement plan. Error: {str(exc)}"


def build_kb_query(user_message, report_context, compact_text):
    query = user_message
    if report_context:
        query += "\n\nUploaded document context summary:\n"
        query += compact_text(report_context, max_chars=3000)
    query += "\n\nFind audit planning guidance: ISA, IFRS, materiality, risk, audit programs."
    return query


def base_system_prompt():
    return """
You are a plain-English audit planning assistant. Write for a business owner or manager
who is NOT an accountant. Follow these strict rules:

LANGUAGE RULES:
- Use simple, short sentences. Maximum 15 words per sentence.
- No jargon without a plain explanation.
- No long paragraphs. Use short bullet points only.
- Each bullet must be one short sentence.
- Maximum 5 bullets per section.
- Use actual numbers from the document (e.g. AED 3,100,000).
- If data is missing, write: Not available.
- NEVER state a specific risk level (High/Medium/Low) for any topic
  that has zero supporting evidence in the document. If a standard
  risk area cannot be evaluated from what was provided, say so
  explicitly (e.g. "To Be Assessed") instead of guessing. Always use
  that exact phrase, not "N/A" or other wording, so it is handled
  consistently everywhere it appears in the report.

FORMAT RULES:
- Use markdown tables where requested.
- Use bullet points (- ) for lists.
- Keep tables to maximum 5 rows.
- Do NOT write long explanations.
- Do NOT repeat information.
"""


def combined_prompt(user_message, report_context, kb_context, citation_details, document_count=1):
    multi_doc_note = ""
    if document_count and document_count > 1:
        multi_doc_note = """

NOTE: More than one document has been provided in the context above. The
FIRST document is the primary financial record being audited. Any
document beyond the first should be treated as supporting evidence
submitted by management — most commonly, evidence submitted in response
to a previously identified risk (e.g. a stock count sheet, a receivables
ageing report, a signed board resolution). Apply this when writing the
Risk Assessment section below.
"""

    return f"""
Financial statement context:
{report_context}
{multi_doc_note}
Knowledge Base:
{kb_context or "None."}

Generate a SHORT, SIMPLE audit planning report. Write for a non-accountant.
Use plain English. Short bullets only. No long paragraphs.

Each section must start with the exact heading shown. Separate sections with: ---

# Engagement Strategy
A simple table:
| Item | Detail |
Show: Who is the client, What will be audited, When, and the main risks.
Maximum 6 rows.

# Planning Memorandum
A simple table:
| Item | Detail |
Show: Audit goal, What is covered, Key dates, Who does what.
Maximum 6 rows.

# Materiality Calculation
Show this table exactly:
| Benchmark | Amount (AED) | % Used | Materiality (AED) |
Use actual numbers from the document.
Then show:
- Overall materiality: AED [amount]
- Performance materiality: AED [amount]
- Trivial threshold: AED [amount]
- Why this benchmark was chosen: [one sentence]

# Risk Assessment
Show this table exactly:
| Risk Area | What it means simply | Risk Level | What the auditor will check |
Use simple plain English in "What it means simply" — one short sentence.
Maximum 8 rows.

CRITICAL — do not invent risk findings:
- Only mark a Risk Area as "High", "Medium", or "Low" if the document
  actually contains numbers, statements, or evidence supporting that
  conclusion (e.g. inventory figures, receivables ageing, revenue
  entries, related party transactions).
- If the document does NOT contain any information about a standard
  risk area (inventory, trade receivables, revenue cutoff, related
  parties, going concern, tax/VAT), do NOT assign it a High or Medium
  risk level. Instead set Risk Level to exactly: To Be Assessed
  and explain in "What the auditor will check" that this requires
  the underlying financial statements, which were not provided.
- Never fabricate a specific risk percentage or level for a topic the
  document does not mention. Absence of data is not evidence of risk.
- If the uploaded document is not a financial statement (e.g. a tax
  payment receipt, invoice, or single-transaction record), most or all
  rows should be "To Be Assessed", plus 1-2 rows genuinely derived
  from what the document DOES show.
- Always use the exact phrase "To Be Assessed" — never "N/A", "Not
  applicable", or any other wording — so it is handled consistently.
- If more than one document is provided in the context above, treat any
  document beyond the first as supporting evidence submitted by
  management in response to a previously identified risk. Assess how
  strongly it addresses THAT SPECIFIC risk's Planned Response, and grade
  your response into exactly one of three tiers:
  1. FULLY RESOLVES — the evidence directly and completely satisfies
     everything the Planned Response asks the auditor to check (e.g. a
     signed related-party confirmation letter matching the balance and
     terms). Move the Risk Level down significantly (e.g. High -> Low),
     and note in the row what was confirmed.
  2. PARTIALLY CORROBORATES — the evidence is genuinely relevant and
     supports part of the Planned Response, but does not fully close
     every element of it (e.g. a bank confirmation shows the related
     party has real assets and liquidity, supporting recoverability,
     but doesn't confirm the loan's exact terms or repayment demand).
     Move the Risk Level down ONE step (e.g. High -> Medium, or
     Medium -> Low), and explicitly note what remains outstanding.
  3. NOT RELEVANT — the evidence does not address this risk's Planned
     Response at all. Leave the Risk Level and reasoning completely
     unchanged.
  Do not skip straight from High to Low unless tier 1 is clearly met.
  Never invent tier 1 or 2 for evidence that is actually tier 3.

# Audit Programs
For each area, write 3 short bullets only. Areas: Inventory, Revenue,
Trade Receivables, Related Parties, Tax/VAT, Going Concern, Disclosures.
Keep each bullet under 12 words.
If the document provides no evidence for a given area, say the
procedures below are standard/default steps pending receipt of the
relevant financial records, rather than presenting them as findings.

# Staffing Recommendations
A simple table:
| Role | Main Job | Hours |
Show: Partner, Manager, Senior, Assistant, Tax Specialist.
Then one line: Total estimated hours: [X]

# Overall Audit Planning Summary
Write one short paragraph (3-4 sentences). Cover:
- What document was actually reviewed (name the client and what the
  document is, e.g. a tax payment slip vs full financial statements).
- Whether meaningful risk levels could be assessed, or whether most
  areas are "To Be Assessed" because financial statements were not
  provided — say this plainly if it is the case.
- The single most important next step (usually: obtain full financial
  statements from management before further audit work can proceed).
- If supporting evidence was provided and resolved any risks, briefly
  mention which ones and why.
Do not repeat the tables above. Write this as plain narrative text.

Do not write anything after the last section.
"""


SECTION_HEADINGS = [
    "Engagement Strategy",
    "Planning Memorandum",
    "Materiality Calculation",
    "Risk Assessment",
    "Audit Programs",
    "Staffing Recommendations",
    "Overall Audit Planning Summary",
]


def ensure_all_sections_present(answer):
    missing = [h for h in SECTION_HEADINGS if f"# {h}" not in answer]
    if not missing:
        return answer
    placeholders = "\n\n---\n\n".join(
        f"# {h}\n\n_Could not be generated._" for h in missing
    )
    return f"{answer.strip()}\n\n---\n\n{placeholders}"


def generate_complete_audit_planning_output(
    invoke_claude, user_message, report_context, kb_context, citation_details, document_count=1,
):
    try:
        result = invoke_claude(
            system_prompt=base_system_prompt(),
            user_prompt=combined_prompt(
                user_message=user_message,
                report_context=report_context,
                kb_context=kb_context,
                citation_details=citation_details,
                document_count=document_count,
            ),
            max_tokens=2500,
            temperature=0,
        )
        answer = (result or "").strip()
    except Exception as exc:
        answer = (
            "# Audit Planning Deliverables\n\n"
            f"_Could not be generated: {str(exc)}_"
        )
        return answer

    answer = ensure_all_sections_present(answer)

    if not answer.lstrip().startswith("# Audit Planning Deliverables"):
        answer = "# Audit Planning Deliverables\n\n---\n\n" + answer.lstrip()

    return answer


class AgentCoreHTTPHandler(BaseHTTPRequestHandler):
    timeout = 120

    def _send_json(self, status_code, payload):
        body = safe_json_dumps(payload).encode("utf-8")
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        self._send_json(200, {
            "status": "ok",
            "agent": AGENT_NAME,
            "message": "Audit Planning AgentCore runtime is running.",
        })

    def do_POST(self):
        try:
            content_length = int(self.headers.get("Content-Length", "0"))
            raw_body = self.rfile.read(content_length).decode("utf-8")
            payload = safe_json_loads(raw_body, {})
            result = run_agent(payload)
            self._send_json(200, result)
        except Exception as exc:
            self._send_json(200, {
                "answer": f"Agent failed: {str(exc)}",
                "error": str(exc),
                "traceback": traceback.format_exc(),
                "selectedAgent": AGENT_NAME,
                "citations": [],
                "sources": [],
            })


def main():
    server = HTTPServer(("0.0.0.0", PORT), AgentCoreHTTPHandler)
    server.timeout = 120
    print(f"Audit Planning AgentCore runtime running on port {PORT}", flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
